-- Run ONCE in Supabase SQL Editor, in a fresh project.
-- Separate PRIVATE drafts from the PUBLIC published snapshot.
-- Never store service-role keys in the website/browser.
create table if not exists public.cv_drafts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.cv_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  data jsonb not null,
  published boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.cv_drafts enable row level security;
alter table public.cv_profiles enable row level security;

create policy "Owners read drafts" on public.cv_drafts
for select to authenticated using (auth.uid() = user_id and (auth.jwt()->>'email') = 'hafizuddin@upc.edu');
create policy "Owners insert drafts" on public.cv_drafts
for insert to authenticated with check (auth.uid() = user_id and (auth.jwt()->>'email') = 'hafizuddin@upc.edu');
create policy "Owners update drafts" on public.cv_drafts
for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id and (auth.jwt()->>'email') = 'hafizuddin@upc.edu');

create policy "Owners read public profiles" on public.cv_profiles
for select to authenticated using (auth.uid() = user_id and (auth.jwt()->>'email') = 'hafizuddin@upc.edu');
create policy "Visitors read published profiles" on public.cv_profiles
for select to anon, authenticated using (published = true);
create policy "Owners insert public profiles" on public.cv_profiles
for insert to authenticated with check (auth.uid() = user_id and (auth.jwt()->>'email') = 'hafizuddin@upc.edu');
create policy "Owners update public profiles" on public.cv_profiles
for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id and (auth.jwt()->>'email') = 'hafizuddin@upc.edu');

create or replace function public.cv_updated_at()
returns trigger as $$ begin new.updated_at = now(); return new; end; $$ language plpgsql;
drop trigger if exists cv_drafts_updated_at on public.cv_drafts;
create trigger cv_drafts_updated_at before update on public.cv_drafts
for each row execute function public.cv_updated_at();
drop trigger if exists cv_profiles_updated_at on public.cv_profiles;
create trigger cv_profiles_updated_at before update on public.cv_profiles
for each row execute function public.cv_updated_at();
