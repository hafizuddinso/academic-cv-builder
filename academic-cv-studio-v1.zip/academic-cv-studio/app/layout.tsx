import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'Academic CV Studio | Hafizuddin',
  description: 'A minimal academic CV, research profile and portfolio builder.'
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
