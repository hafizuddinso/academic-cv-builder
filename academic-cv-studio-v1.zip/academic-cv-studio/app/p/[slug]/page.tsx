import { createClient } from '@supabase/supabase-js';
import { notFound } from 'next/navigation';
import CVDocument from '@/components/CVDocument';
import type { CVData } from '@/lib/cv';
import PublicActions from '@/components/PublicActions';
export const dynamic = 'force-dynamic';
export default async function PublicProfile({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) notFound();
  const client = createClient(url, key, { auth: { persistSession: false } });
  const { data, error } = await client.from('cv_profiles').select('data,slug').eq('slug', slug).eq('published', true).maybeSingle();
  if (error || !data) notFound();
  const cv = data.data as CVData;
  return <div className="public-wrap"><div className="public-toolbar"><a href="/" className="brand-mini">CV STUDIO<span> / PUBLIC PROFILE</span></a><PublicActions/></div><div className="public-paper"><CVDocument cv={cv}/></div></div>;
}
